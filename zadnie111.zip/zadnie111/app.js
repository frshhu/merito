document.getElementById("contactForm").addEventListener("submit", function(event){
    event.preventDefault();

    const name = document.getElementById('name').value.trim();
    const email = document.getElementById('email').value.trim();
    const message = document.getElementById('message').value.trim();
    const phone = document.getElementById('phone').value.trim();
    const age = document.getElementById('age').value.trim();
    

    const gender = document.querySelector('input[name="gender"]:checked')?.value || "Nie podano";
    
    const interests = Array.from(document.querySelectorAll('input[name="interests"]:checked'))
    .map(checkbox => checkbox.value)
    .join(", ") || "Brak zainteresowań";

    const contactConsent = Array.from(document.querySelectorAll('input[name="contactConsent"]:checked'))
    .map(checkbox => checkbox.value)
    .join(", ") || "Brak Zgody";

   

    clearErrors();

    let isValid = true;

    if (name.length < 2) {
        displayError('name', 'Imię musi mieć co najmniej 2 znaki')
        isValid = false;
    }
    
    if (message.length < 5){
        displayError('message', 'Wiadomość musi mieć minimum 5 znaków')
        isValid = false;
      }
    
   const emailPattern = /^[^\s@]+@[^\s@]+.[^\s@]+$/;
   if (!emailPattern.test(email)) {
     displayError('email', 'Podaj poprawny adres e-mail');
      isValid = false;
    }
   
    if (phone.length < 10) {
        displayError('phone', 'Numer telefonu musi miec')
        isValid = false;
    }
   
      if (isValid) {
        const resultDiv = document.getElementById('result');
        resultDiv.innerHTML = `
        <h3>Podsumowanie:</h3>
        <p><strong>Imię:</strong>${name}</p>
        <p><strong>Email:</strong>${email}</p>
        <p><strong>Numer telefonu:</strong>${phone}</p>
        <p><strong>Wiek:</strong>${age}</p>
        <p><strong>Płeć:</strong>${gender}</p>
        <p><strong>Zainteresowania:</strong>${interests}</p>
        <p><strong>Wiadomości:</strong>${message}</p>
        <p><strong>Zgoda na kontakt:</strong>${contactConsent}</p>
        
        `;  
    }
    

    
    
 
 
    
    
});

function clearErrors(){
    const errors = document.getElementsByClassName('error-message');
    while(errors.length > 0){
      errors[0].parentNode.removeChild(errors[0]);
    }
}

function displayError(fieldId, message){
    const field = document.getElementById(fieldId);
    const errorDiv = document.createElement('div');
    errorDiv.className = 'error-message';
    errorDiv.textContent = message;
    field.parentNode.insertBefore(errorDiv, field.nextSibling);
}
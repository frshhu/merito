<?php
   return [
    'username'=> 'admin',
    'password_hash' => '$2y$10$FZ7K955p1wXXTJgrftnmzekQL1aYDcPNsE7HWSdiCSixUsMkcZ99e'
   ];
   